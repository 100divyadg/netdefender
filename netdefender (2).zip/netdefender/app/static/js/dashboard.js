/* NetDefender dashboard */

const CLASSES = ["DoS", "Normal", "Probe", "R2L", "U2R"];
const STRIP_CELLS = 60;

const PRESETS = {
  normal: {
    protocol_type: "tcp", service: "http", flag: "SF",
    duration: 0, src_bytes: 215, dst_bytes: 45076,
    count: 1, srv_count: 1, serror_rate: 0,
    dst_host_count: 255, dst_host_srv_count: 255,
  },
  dos: {
    protocol_type: "tcp", service: "private", flag: "S0",
    duration: 0, src_bytes: 0, dst_bytes: 0,
    count: 511, srv_count: 511, serror_rate: 1,
    dst_host_count: 255, dst_host_srv_count: 12,
  },
  probe: {
    protocol_type: "tcp", service: "private", flag: "REJ",
    duration: 0, src_bytes: 0, dst_bytes: 0,
    count: 121, srv_count: 19, serror_rate: 0,
    dst_host_count: 255, dst_host_srv_count: 19,
  },
};

const FIELD_IDS = [
  "protocol_type", "service", "flag", "duration", "src_bytes", "dst_bytes",
  "count", "srv_count", "serror_rate", "dst_host_count", "dst_host_srv_count",
];

let scored = 0;

/* ---------- traffic strip ---------- */
function initStrip() {
  const strip = document.getElementById("strip");
  strip.innerHTML = "";
  for (let i = 0; i < STRIP_CELLS; i++) {
    const cell = document.createElement("div");
    cell.className = "cell";
    strip.appendChild(cell);
  }
}

function pushToStrip(label) {
  const strip = document.getElementById("strip");
  const cell = document.createElement("div");
  cell.className = "cell " + label.toLowerCase();
  strip.appendChild(cell);
  if (strip.children.length > STRIP_CELLS) strip.removeChild(strip.firstChild);

  scored += 1;
  document.getElementById("strip-count").textContent =
    scored + (scored === 1 ? " record scored" : " records scored");
}

/* ---------- form ---------- */
function readForm() {
  const record = {};
  FIELD_IDS.forEach((id) => {
    const el = document.getElementById(id);
    if (!el) return;
    const raw = el.value;
    const num = Number(raw);
    record[id] = raw !== "" && !Number.isNaN(num) && el.type === "number" ? num : raw;
  });
  record.model = document.getElementById("model").value;
  return record;
}

function applyPreset(name) {
  const preset = PRESETS[name];
  Object.entries(preset).forEach(([k, v]) => {
    const el = document.getElementById(k);
    if (el) el.value = v;
  });
}

/* ---------- verdict ---------- */
function renderVerdict(result) {
  const box = document.getElementById("verdict");
  const label = document.getElementById("verdict-label");
  const meta = document.getElementById("verdict-meta");
  const bars = document.getElementById("verdict-bars");

  box.classList.add("show");
  label.textContent = result.prediction;
  label.className = "label " + (result.is_attack ? "attack" : "clean");
  meta.textContent =
    `confidence ${(result.confidence * 100).toFixed(1)}%  ·  ${result.model}`;

  bars.innerHTML = "";
  CLASSES.forEach((cls) => {
    const p = result.probabilities[cls] || 0;
    const row = document.createElement("div");
    row.className = "bar-row";
    row.innerHTML =
      `<span>${cls}</span>` +
      `<span class="bar-track"><span class="bar-fill" style="width:${(p * 100).toFixed(1)}%"></span></span>` +
      `<span>${(p * 100).toFixed(1)}%</span>`;
    bars.appendChild(row);
  });
}

function showError(message) {
  const box = document.getElementById("verdict");
  const label = document.getElementById("verdict-label");
  box.classList.add("show");
  label.textContent = "Cannot classify";
  label.className = "label attack";
  document.getElementById("verdict-meta").textContent = message;
  document.getElementById("verdict-bars").innerHTML = "";
}

/* ---------- alerts ---------- */
async function refreshAlerts() {
  try {
    const res = await fetch("/api/alerts");
    const data = await res.json();
    const list = document.getElementById("alerts");

    if (!data.alerts.length) {
      list.innerHTML = '<div class="empty">Nothing flagged yet.</div>';
      return;
    }

    list.innerHTML = data.alerts
      .map(
        (a) =>
          `<div class="alert">
             <span class="kind ${a.attack_type}">${a.attack_type}</span>
             <span class="when">${a.timestamp}</span>
             <span class="conf">${(a.confidence * 100).toFixed(0)}%</span>
           </div>`
      )
      .join("");
  } catch (err) {
    /* leave the last good list on screen */
  }
}

/* ---------- batch ---------- */
async function uploadCsv(file) {
  const out = document.getElementById("batch-out");
  out.innerHTML = '<div class="empty">Scoring rows…</div>';

  const form = new FormData();
  form.append("file", file);
  form.append("model", document.getElementById("model").value);

  try {
    const res = await fetch("/api/predict/batch", { method: "POST", body: form });
    const data = await res.json();

    if (data.error) {
      out.innerHTML = `<div class="empty">${data.error}</div>`;
      return;
    }

    const rows = Object.entries(data.breakdown)
      .map(([k, v]) => `<tr><td>${k}</td><td>${v}</td></tr>`)
      .join("");

    out.innerHTML =
      `<div class="stat-row">
         <div class="stat"><div class="n">${data.total}</div><div class="k">records</div></div>
         <div class="stat"><div class="n" style="color:var(--signal)">${data.attacks}</div><div class="k">attacks</div></div>
       </div>
       <table><thead><tr><th>Class</th><th>Count</th></tr></thead><tbody>${rows}</tbody></table>`;

    Object.entries(data.breakdown).forEach(([cls, n]) => {
      for (let i = 0; i < Math.min(n, 12); i++) pushToStrip(cls);
    });
    refreshAlerts();
  } catch (err) {
    out.innerHTML = '<div class="empty">Upload failed. Check the file format.</div>';
  }
}

/* ---------- wiring ---------- */
document.addEventListener("DOMContentLoaded", () => {
  initStrip();
  refreshAlerts();
  setInterval(refreshAlerts, 5000);

  document.getElementById("run").addEventListener("click", async () => {
    const payload = readForm();
    try {
      const res = await fetch("/api/predict", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (data.error) {
        showError(data.error);
        return;
      }
      renderVerdict(data);
      pushToStrip(data.prediction);
      refreshAlerts();
    } catch (err) {
      showError("The server did not respond.");
    }
  });

  document.querySelectorAll("[data-preset]").forEach((btn) => {
    btn.addEventListener("click", () => applyPreset(btn.dataset.preset));
  });

  const csv = document.getElementById("csv");
  csv.addEventListener("change", (e) => {
    if (e.target.files.length) uploadCsv(e.target.files[0]);
  });

  const zone = document.querySelector(".upload-zone");
  zone.addEventListener("dragover", (e) => e.preventDefault());
  zone.addEventListener("drop", (e) => {
    e.preventDefault();
    if (e.dataTransfer.files.length) uploadCsv(e.dataTransfer.files[0]);
  });
});
