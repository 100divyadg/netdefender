"""Random Forest baseline.

This is the benchmark the deep models are measured against. It trains in
seconds on CPU and gives a feature importance ranking for free, which is what
makes it useful to a security analyst reading the results.
"""

from __future__ import annotations

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier

from src.config import MODEL_DIR, RF_PARAMS


def build() -> RandomForestClassifier:
    return RandomForestClassifier(**RF_PARAMS)


def train(X_train: np.ndarray, y_train: np.ndarray) -> RandomForestClassifier:
    model = build()
    model.fit(X_train, y_train)
    return model


def feature_importance(
    model: RandomForestClassifier,
    feature_names: list[str],
    top_n: int = 20,
) -> pd.DataFrame:
    """Return the top_n most influential features as a tidy DataFrame."""
    names = feature_names or [f"f{i}" for i in range(len(model.feature_importances_))]
    frame = pd.DataFrame(
        {
            "feature": names[: len(model.feature_importances_)],
            "importance": model.feature_importances_,
        }
    )
    return (
        frame.sort_values("importance", ascending=False)
        .head(top_n)
        .reset_index(drop=True)
    )


def save(model: RandomForestClassifier, name: str = "random_forest.joblib") -> None:
    joblib.dump(model, MODEL_DIR / name)


def load(name: str = "random_forest.joblib") -> RandomForestClassifier:
    return joblib.load(MODEL_DIR / name)
