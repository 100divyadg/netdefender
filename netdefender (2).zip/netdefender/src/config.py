"""Central configuration for the NetDefender project.

Every path, column list and hyperparameter used across the pipeline lives here so
that experiments stay reproducible and nothing is hard coded in the scripts.
"""

from pathlib import Path

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
ROOT_DIR = Path(__file__).resolve().parents[1]

DATA_DIR = ROOT_DIR / "data"
RAW_DIR = DATA_DIR / "raw"
PROCESSED_DIR = DATA_DIR / "processed"

MODEL_DIR = ROOT_DIR / "models"
RESULTS_DIR = ROOT_DIR / "results"
FIGURE_DIR = RESULTS_DIR / "figures"
METRIC_DIR = RESULTS_DIR / "metrics"

for _d in (RAW_DIR, PROCESSED_DIR, MODEL_DIR, FIGURE_DIR, METRIC_DIR):
    _d.mkdir(parents=True, exist_ok=True)

TRAIN_FILE = RAW_DIR / "KDDTrain+.txt"
TEST_FILE = RAW_DIR / "KDDTest+.txt"

# ---------------------------------------------------------------------------
# NSL-KDD schema
# ---------------------------------------------------------------------------
COLUMN_NAMES = [
    "duration", "protocol_type", "service", "flag", "src_bytes", "dst_bytes",
    "land", "wrong_fragment", "urgent", "hot", "num_failed_logins",
    "logged_in", "num_compromised", "root_shell", "su_attempted", "num_root",
    "num_file_creations", "num_shells", "num_access_files",
    "num_outbound_cmds", "is_host_login", "is_guest_login", "count",
    "srv_count", "serror_rate", "srv_serror_rate", "rerror_rate",
    "srv_rerror_rate", "same_srv_rate", "diff_srv_rate", "srv_diff_host_rate",
    "dst_host_count", "dst_host_srv_count", "dst_host_same_srv_rate",
    "dst_host_diff_srv_rate", "dst_host_same_src_port_rate",
    "dst_host_srv_diff_host_rate", "dst_host_serror_rate",
    "dst_host_srv_serror_rate", "dst_host_rerror_rate",
    "dst_host_srv_rerror_rate", "outcome", "difficulty",
]

CATEGORICAL_COLUMNS = ["protocol_type", "service", "flag"]
DROP_COLUMNS = ["difficulty", "num_outbound_cmds"]

# ---------------------------------------------------------------------------
# Attack taxonomy: the 39 granular NSL-KDD labels collapse to five classes
# ---------------------------------------------------------------------------
ATTACK_MAP = {
    "normal": "Normal",
    # Denial of Service
    "neptune": "DoS", "back": "DoS", "land": "DoS", "pod": "DoS",
    "smurf": "DoS", "teardrop": "DoS", "mailbomb": "DoS",
    "apache2": "DoS", "processtable": "DoS", "udpstorm": "DoS",
    "worm": "DoS",
    # Probe / reconnaissance
    "ipsweep": "Probe", "nmap": "Probe", "portsweep": "Probe",
    "satan": "Probe", "mscan": "Probe", "saint": "Probe",
    # Remote to Local
    "ftp_write": "R2L", "guess_passwd": "R2L", "imap": "R2L",
    "multihop": "R2L", "phf": "R2L", "spy": "R2L", "warezclient": "R2L",
    "warezmaster": "R2L", "sendmail": "R2L", "named": "R2L",
    "snmpgetattack": "R2L", "snmpguess": "R2L", "xlock": "R2L",
    "xsnoop": "R2L", "httptunnel": "R2L",
    # User to Root
    "buffer_overflow": "U2R", "loadmodule": "U2R", "perl": "U2R",
    "rootkit": "U2R", "ps": "U2R", "sqlattack": "U2R", "xterm": "U2R",
}

# NOTE: this list MUST stay in sorted order.
# sklearn's LabelEncoder assigns integer codes alphabetically, so index i here
# must be the same class LabelEncoder maps to i. Reordering this list without
# reordering the encoder silently swaps predicted labels, e.g. a SYN flood
# comes back as Normal with high confidence.
CLASS_NAMES = sorted(["Normal", "DoS", "Probe", "R2L", "U2R"])
N_CLASSES = len(CLASS_NAMES)

# The class treated as benign; everything else raises an alert.
NORMAL_CLASS = "Normal"

# ---------------------------------------------------------------------------
# Experiment settings
# ---------------------------------------------------------------------------
RANDOM_STATE = 42
TEST_SIZE = 0.20
VAL_SIZE = 0.10

RF_PARAMS = {
    "n_estimators": 200,
    "max_depth": None,
    "min_samples_split": 2,
    "class_weight": "balanced_subsample",
    "n_jobs": -1,
    "random_state": RANDOM_STATE,
}

MLP_PARAMS = {
    "hidden_units": [256, 128, 64],
    "dropout": 0.3,
    "learning_rate": 1e-3,
    "epochs": 40,
    "batch_size": 256,
}

CNN_LSTM_PARAMS = {
    "conv_filters": [64, 128],
    "kernel_size": 3,
    "lstm_units": 128,
    "dropout": 0.3,
    "learning_rate": 1e-3,
    "epochs": 40,
    "batch_size": 256,
}

PCA_COMPONENTS = 30
SMOTE_STRATEGY = "auto"
