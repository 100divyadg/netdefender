"""Preprocessing pipeline for the NSL-KDD dataset.

Handles label collapsing, one hot encoding of the three categorical columns,
scaling, optional class balancing with SMOTE and optional PCA reduction. The
fitted transformers are persisted so that the Flask app can apply exactly the
same transformation to live traffic records.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import joblib
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, MinMaxScaler, OneHotEncoder

from src.config import (
    ATTACK_MAP,
    CATEGORICAL_COLUMNS,
    CLASS_NAMES,
    COLUMN_NAMES,
    DROP_COLUMNS,
    MODEL_DIR,
    PCA_COMPONENTS,
    PROCESSED_DIR,
    RANDOM_STATE,
    TEST_FILE,
    TRAIN_FILE,
    VAL_SIZE,
)


@dataclass
class Dataset:
    """Container for one prepared train/validation/test split."""

    X_train: np.ndarray
    y_train: np.ndarray
    X_val: np.ndarray
    y_val: np.ndarray
    X_test: np.ndarray
    y_test: np.ndarray
    feature_names: list[str] = field(default_factory=list)

    @property
    def n_features(self) -> int:
        return int(self.X_train.shape[1])

    def summary(self) -> str:
        return (
            f"train={self.X_train.shape}  val={self.X_val.shape}  "
            f"test={self.X_test.shape}  features={self.n_features}"
        )


def load_raw(path) -> pd.DataFrame:
    """Read one NSL-KDD text file into a DataFrame with proper column names."""
    return pd.read_csv(path, names=COLUMN_NAMES, header=None)


def collapse_labels(df: pd.DataFrame) -> pd.DataFrame:
    """Map the granular outcome column onto the five headline classes."""
    df = df.copy()
    df["outcome"] = df["outcome"].str.replace(".", "", regex=False).str.strip()
    df["attack_class"] = df["outcome"].map(ATTACK_MAP)
    unknown = df["attack_class"].isna().sum()
    if unknown:
        # Anything outside the published taxonomy is treated conservatively as
        # an attack rather than silently dropped.
        df["attack_class"] = df["attack_class"].fillna("R2L")
    return df.drop(columns=["outcome"])


def build_encoder(df: pd.DataFrame) -> ColumnTransformer:
    """One hot encode the categorical columns and min max scale the rest."""
    numeric = [
        c
        for c in df.columns
        if c not in CATEGORICAL_COLUMNS + ["attack_class"] + DROP_COLUMNS
    ]
    return ColumnTransformer(
        transformers=[
            (
                "cat",
                OneHotEncoder(handle_unknown="ignore", sparse_output=False),
                CATEGORICAL_COLUMNS,
            ),
            ("num", MinMaxScaler(), numeric),
        ],
        remainder="drop",
    )


def _feature_names(encoder: ColumnTransformer) -> list[str]:
    try:
        return list(encoder.get_feature_names_out())
    except Exception:  # noqa: BLE001
        return []


def prepare(
    use_smote: bool = True,
    use_pca: bool = False,
    save: bool = True,
) -> Dataset:
    """Run the full pipeline and return a ready to train Dataset."""
    train_df = collapse_labels(load_raw(TRAIN_FILE))
    test_df = collapse_labels(load_raw(TEST_FILE))

    for frame in (train_df, test_df):
        frame.drop(columns=[c for c in DROP_COLUMNS if c in frame], inplace=True)

    y_train_raw = train_df.pop("attack_class")
    y_test_raw = test_df.pop("attack_class")

    label_encoder = LabelEncoder().fit(CLASS_NAMES)

    # Guard against the ordering trap: CLASS_NAMES is used to turn predicted
    # integers back into labels, so it must agree with the encoder exactly.
    if list(label_encoder.classes_) != list(CLASS_NAMES):
        raise RuntimeError(
            "CLASS_NAMES does not match LabelEncoder ordering. "
            f"encoder={list(label_encoder.classes_)} config={list(CLASS_NAMES)}. "
            "CLASS_NAMES must be sorted."
        )

    y_train_all = label_encoder.transform(y_train_raw)
    y_test = label_encoder.transform(y_test_raw)

    encoder = build_encoder(train_df.assign(attack_class="Normal"))
    X_train_all = encoder.fit_transform(train_df)
    X_test = encoder.transform(test_df)
    feature_names = _feature_names(encoder)

    X_train, X_val, y_train, y_val = train_test_split(
        X_train_all,
        y_train_all,
        test_size=VAL_SIZE,
        random_state=RANDOM_STATE,
        stratify=y_train_all,
    )

    if use_smote:
        X_train, y_train = apply_smote(X_train, y_train)

    pca = None
    if use_pca:
        from sklearn.decomposition import PCA

        pca = PCA(n_components=PCA_COMPONENTS, random_state=RANDOM_STATE)
        X_train = pca.fit_transform(X_train)
        X_val = pca.transform(X_val)
        X_test = pca.transform(X_test)
        feature_names = [f"pc{i + 1}" for i in range(X_train.shape[1])]

    if save:
        joblib.dump(encoder, MODEL_DIR / "encoder.joblib")
        joblib.dump(label_encoder, MODEL_DIR / "label_encoder.joblib")
        if pca is not None:
            joblib.dump(pca, MODEL_DIR / "pca.joblib")
        np.savez_compressed(
            PROCESSED_DIR / "nslkdd.npz",
            X_train=X_train,
            y_train=y_train,
            X_val=X_val,
            y_val=y_val,
            X_test=X_test,
            y_test=y_test,
        )

    return Dataset(
        X_train=X_train.astype(np.float32),
        y_train=y_train.astype(np.int64),
        X_val=X_val.astype(np.float32),
        y_val=y_val.astype(np.int64),
        X_test=X_test.astype(np.float32),
        y_test=y_test.astype(np.int64),
        feature_names=feature_names,
    )


def apply_smote(X: np.ndarray, y: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Oversample the minority classes, which for NSL-KDD means U2R and R2L.

    U2R holds roughly fifty records against tens of thousands of DoS samples, so
    without rebalancing the classifier simply never predicts it.
    """
    try:
        from imblearn.over_sampling import SMOTE
    except ImportError:
        print("[warn] imbalanced-learn not installed, skipping SMOTE")
        return X, y

    counts = np.bincount(y)
    smallest = counts[counts > 0].min()
    k = max(1, min(5, int(smallest) - 1))
    sampler = SMOTE(random_state=RANDOM_STATE, k_neighbors=k)
    return sampler.fit_resample(X, y)


def load_cached() -> Dataset:
    """Reload a previously prepared split without recomputing anything."""
    blob = np.load(PROCESSED_DIR / "nslkdd.npz")
    return Dataset(
        X_train=blob["X_train"],
        y_train=blob["y_train"],
        X_val=blob["X_val"],
        y_val=blob["y_val"],
        X_test=blob["X_test"],
        y_test=blob["y_test"],
    )


if __name__ == "__main__":
    data = prepare()
    print(data.summary())
