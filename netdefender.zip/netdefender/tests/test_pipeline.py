"""Unit tests that run without the dataset present."""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from src.config import ATTACK_MAP, CLASS_NAMES, COLUMN_NAMES, N_CLASSES
from src.data.preprocess import build_encoder, collapse_labels
from src.utils.evaluate import comparison_table, compute_metrics


def make_frame(n: int = 40) -> pd.DataFrame:
    rng = np.random.default_rng(0)
    data = {c: rng.integers(0, 100, n) for c in COLUMN_NAMES}
    data["protocol_type"] = rng.choice(["tcp", "udp", "icmp"], n)
    data["service"] = rng.choice(["http", "private", "smtp"], n)
    data["flag"] = rng.choice(["SF", "S0", "REJ"], n)
    data["outcome"] = rng.choice(["normal", "neptune", "satan", "perl"], n)
    return pd.DataFrame(data)


class TestTaxonomy:
    def test_every_label_maps_to_a_known_class(self):
        assert set(ATTACK_MAP.values()) <= set(CLASS_NAMES)

    def test_five_classes(self):
        assert N_CLASSES == 5

    def test_normal_is_not_an_attack_label(self):
        assert ATTACK_MAP["normal"] == "Normal"

    def test_known_attacks_map_correctly(self):
        assert ATTACK_MAP["neptune"] == "DoS"
        assert ATTACK_MAP["satan"] == "Probe"
        assert ATTACK_MAP["perl"] == "U2R"
        assert ATTACK_MAP["guess_passwd"] == "R2L"


class TestLabelOrdering:
    """Regression guard.

    sklearn's LabelEncoder assigns codes alphabetically. CLASS_NAMES is used to
    convert predicted integers back into names, so if the two disagree the
    system reports confident, completely wrong labels: a SYN flood comes back
    as Normal. This test pins the two together.
    """

    def test_class_names_are_sorted(self):
        assert list(CLASS_NAMES) == sorted(CLASS_NAMES)

    def test_class_names_match_label_encoder(self):
        from sklearn.preprocessing import LabelEncoder

        encoder = LabelEncoder().fit(CLASS_NAMES)
        assert list(encoder.classes_) == list(CLASS_NAMES)

    def test_round_trip_is_identity(self):
        from sklearn.preprocessing import LabelEncoder

        encoder = LabelEncoder().fit(CLASS_NAMES)
        for name in CLASS_NAMES:
            code = int(encoder.transform([name])[0])
            assert CLASS_NAMES[code] == name


class TestCollapseLabels:
    def test_creates_attack_class_column(self):
        out = collapse_labels(make_frame())
        assert "attack_class" in out.columns
        assert "outcome" not in out.columns

    def test_no_unmapped_rows(self):
        out = collapse_labels(make_frame())
        assert out["attack_class"].isna().sum() == 0

    def test_values_are_valid_classes(self):
        out = collapse_labels(make_frame())
        assert set(out["attack_class"].unique()) <= set(CLASS_NAMES)


class TestEncoder:
    def test_output_is_all_numeric(self):
        df = collapse_labels(make_frame())
        encoder = build_encoder(df)
        X = encoder.fit_transform(df.drop(columns=["attack_class"]))
        assert np.issubdtype(np.asarray(X).dtype, np.number)

    def test_expands_categoricals(self):
        df = collapse_labels(make_frame())
        raw = df.drop(columns=["attack_class"])
        encoder = build_encoder(df)
        X = encoder.fit_transform(raw)
        assert X.shape[1] > raw.shape[1]

    def test_unseen_category_does_not_crash(self):
        df = collapse_labels(make_frame())
        encoder = build_encoder(df)
        encoder.fit(df.drop(columns=["attack_class"]))

        novel = df.drop(columns=["attack_class"]).head(1).copy()
        novel["service"] = "some_new_service"
        assert encoder.transform(novel).shape[0] == 1


class TestMetrics:
    def test_perfect_prediction_scores_one(self):
        y = np.array([0, 1, 2, 3, 4])
        m = compute_metrics(y, y, model_name="perfect")
        assert m["accuracy"] == pytest.approx(1.0)
        assert m["f1_macro"] == pytest.approx(1.0)

    def test_confusion_matrix_is_square(self):
        y = np.array([0, 1, 2, 3, 4])
        m = compute_metrics(y, y, model_name="m")
        assert np.array(m["confusion_matrix"]).shape == (N_CLASSES, N_CLASSES)

    def test_per_class_covers_all_classes(self):
        y = np.array([0, 0, 1, 1])
        m = compute_metrics(y, np.array([0, 1, 1, 1]), model_name="m")
        assert set(m["per_class"]) == set(CLASS_NAMES)

    def test_comparison_table_has_one_row_per_model(self):
        y = np.array([0, 1, 2, 3, 4])
        rows = [compute_metrics(y, y, model_name=n) for n in ("A", "B")]
        table = comparison_table(rows)
        assert len(table) == 2
        assert "U2R recall" in table.columns
