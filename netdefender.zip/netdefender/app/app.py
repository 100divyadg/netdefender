"""Flask backend for the NetDefender dashboard.

Serves the monitoring UI and a small JSON API. Predictions are delegated to
src.predict.Detector, so this file stays purely a transport layer.
"""

from __future__ import annotations

import io
import json
import sys
from collections import deque
from datetime import datetime
from pathlib import Path

import pandas as pd
from flask import Flask, jsonify, render_template, request

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from src.config import CLASS_NAMES, METRIC_DIR, RESULTS_DIR  # noqa: E402
from src.predict import Detector  # noqa: E402

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 16 * 1024 * 1024

DETECTORS: dict[str, Detector] = {}
ALERT_LOG: deque = deque(maxlen=200)


def get_detector(name: str = "random_forest") -> Detector:
    if name not in DETECTORS:
        DETECTORS[name] = Detector(name)
    return DETECTORS[name]


def log_alert(result: dict, source: str = "manual") -> None:
    if result.get("is_attack"):
        ALERT_LOG.appendleft(
            {
                "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "attack_type": result["prediction"],
                "confidence": round(result["confidence"], 4),
                "model": result["model"],
                "source": source,
            }
        )


# ---------------------------------------------------------------------------
# Pages
# ---------------------------------------------------------------------------
@app.route("/")
def index():
    return render_template("index.html", classes=CLASS_NAMES)


@app.route("/results")
def results_page():
    return render_template("results.html")


# ---------------------------------------------------------------------------
# API
# ---------------------------------------------------------------------------
@app.route("/api/health")
def health():
    from src.config import MODEL_DIR

    available = []
    if (MODEL_DIR / "random_forest.joblib").exists():
        available.append("random_forest")
    for name in ("mlp", "cnn_lstm"):
        if (MODEL_DIR / f"{name}.keras").exists():
            available.append(name)

    return jsonify(
        {
            "status": "ok",
            "models": available,
            "trained": bool(available),
        }
    )


@app.route("/api/predict", methods=["POST"])
def predict():
    payload = request.get_json(silent=True) or {}
    model_name = payload.pop("model", "random_forest")
    try:
        detector = get_detector(model_name)
        result = detector.predict(payload)
        log_alert(result)
        return jsonify(result)
    except FileNotFoundError as exc:
        return jsonify({"error": str(exc)}), 503
    except Exception as exc:  # noqa: BLE001
        return jsonify({"error": f"prediction failed: {exc}"}), 400


@app.route("/api/predict/batch", methods=["POST"])
def predict_batch():
    if "file" not in request.files:
        return jsonify({"error": "no file uploaded"}), 400

    model_name = request.form.get("model", "random_forest")
    upload = request.files["file"]

    try:
        raw = upload.read().decode("utf-8")
        df = pd.read_csv(io.StringIO(raw))
        detector = get_detector(model_name)
        scored = detector.predict_batch(df)

        counts = scored["prediction"].value_counts().to_dict()
        for _, row in scored[scored["is_attack"]].head(50).iterrows():
            log_alert(
                {
                    "is_attack": True,
                    "prediction": row["prediction"],
                    "confidence": float(row["confidence"]),
                    "model": model_name,
                },
                source=upload.filename,
            )

        return jsonify(
            {
                "total": int(len(scored)),
                "attacks": int(scored["is_attack"].sum()),
                "breakdown": {k: int(v) for k, v in counts.items()},
                "sample": scored.head(20).to_dict(orient="records"),
            }
        )
    except FileNotFoundError as exc:
        return jsonify({"error": str(exc)}), 503
    except Exception as exc:  # noqa: BLE001
        return jsonify({"error": f"batch failed: {exc}"}), 400


@app.route("/api/alerts")
def alerts():
    return jsonify({"alerts": list(ALERT_LOG)})


@app.route("/api/metrics")
def metrics():
    payload = {}
    for path in METRIC_DIR.glob("*.json"):
        with open(path) as fh:
            payload[path.stem] = json.load(fh)

    comparison_path = RESULTS_DIR / "comparison.csv"
    if comparison_path.exists():
        payload["comparison"] = pd.read_csv(comparison_path).to_dict(orient="records")

    return jsonify(payload)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
