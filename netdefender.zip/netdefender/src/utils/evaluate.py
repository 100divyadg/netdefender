"""Evaluation helpers shared by all three models.

Accuracy on NSL-KDD is a misleading headline number because Normal and DoS
together make up the overwhelming majority of records. The functions here always
report per class precision, recall and F1 alongside it, plus macro averages that
weight U2R as heavily as DoS.
"""

from __future__ import annotations

import json
from typing import Any

import numpy as np
import pandas as pd
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
)

from src.config import CLASS_NAMES, FIGURE_DIR, METRIC_DIR


def compute_metrics(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    y_proba: np.ndarray | None = None,
    model_name: str = "model",
) -> dict[str, Any]:
    """Return the full metric bundle for one model."""
    metrics: dict[str, Any] = {
        "model": model_name,
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "precision_macro": float(
            precision_score(y_true, y_pred, average="macro", zero_division=0)
        ),
        "recall_macro": float(
            recall_score(y_true, y_pred, average="macro", zero_division=0)
        ),
        "f1_macro": float(f1_score(y_true, y_pred, average="macro", zero_division=0)),
        "f1_weighted": float(
            f1_score(y_true, y_pred, average="weighted", zero_division=0)
        ),
    }

    if y_proba is not None:
        try:
            present = np.unique(y_true)
            metrics["auc_roc_ovr"] = float(
                roc_auc_score(
                    y_true,
                    y_proba[:, present],
                    multi_class="ovr",
                    average="macro",
                    labels=present,
                )
            )
        except Exception:  # noqa: BLE001
            metrics["auc_roc_ovr"] = None

    report = classification_report(
        y_true,
        y_pred,
        labels=list(range(len(CLASS_NAMES))),
        target_names=CLASS_NAMES,
        output_dict=True,
        zero_division=0,
    )
    metrics["per_class"] = {
        name: {
            "precision": float(report[name]["precision"]),
            "recall": float(report[name]["recall"]),
            "f1": float(report[name]["f1-score"]),
            "support": int(report[name]["support"]),
        }
        for name in CLASS_NAMES
    }
    metrics["confusion_matrix"] = confusion_matrix(
        y_true, y_pred, labels=list(range(len(CLASS_NAMES)))
    ).tolist()
    return metrics


def print_report(metrics: dict[str, Any]) -> None:
    print(f"\n{'=' * 62}")
    print(f"  {metrics['model']}")
    print("=" * 62)
    print(f"  Accuracy        : {metrics['accuracy']:.4f}")
    print(f"  Precision macro : {metrics['precision_macro']:.4f}")
    print(f"  Recall macro    : {metrics['recall_macro']:.4f}")
    print(f"  F1 macro        : {metrics['f1_macro']:.4f}")
    if metrics.get("auc_roc_ovr"):
        print(f"  AUC ROC (ovr)   : {metrics['auc_roc_ovr']:.4f}")
    print(f"\n  {'class':<10}{'prec':>9}{'recall':>9}{'f1':>9}{'support':>10}")
    print("  " + "-" * 47)
    for name, vals in metrics["per_class"].items():
        print(
            f"  {name:<10}{vals['precision']:>9.4f}{vals['recall']:>9.4f}"
            f"{vals['f1']:>9.4f}{vals['support']:>10d}"
        )


def save_metrics(metrics: dict[str, Any], filename: str | None = None) -> None:
    filename = filename or f"{metrics['model'].lower().replace(' ', '_')}.json"
    with open(METRIC_DIR / filename, "w") as fh:
        json.dump(metrics, fh, indent=2)


def plot_confusion_matrix(metrics: dict[str, Any], save: bool = True):
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    cm = np.array(metrics["confusion_matrix"])
    cm_norm = cm.astype(float) / np.maximum(cm.sum(axis=1, keepdims=True), 1)

    fig, ax = plt.subplots(figsize=(7, 6))
    im = ax.imshow(cm_norm, cmap="Blues", vmin=0, vmax=1)
    ax.set_xticks(range(len(CLASS_NAMES)), CLASS_NAMES, rotation=45, ha="right")
    ax.set_yticks(range(len(CLASS_NAMES)), CLASS_NAMES)
    ax.set_xlabel("Predicted")
    ax.set_ylabel("Actual")
    ax.set_title(f"Confusion matrix: {metrics['model']}")

    for i in range(len(CLASS_NAMES)):
        for j in range(len(CLASS_NAMES)):
            ax.text(
                j,
                i,
                f"{cm[i, j]}",
                ha="center",
                va="center",
                color="white" if cm_norm[i, j] > 0.5 else "black",
                fontsize=9,
            )

    fig.colorbar(im, ax=ax, fraction=0.046)
    fig.tight_layout()

    if save:
        slug = metrics["model"].lower().replace(" ", "_")
        fig.savefig(FIGURE_DIR / f"confusion_{slug}.png", dpi=150)
    plt.close(fig)


def comparison_table(all_metrics: list[dict[str, Any]]) -> pd.DataFrame:
    """Build the headline model comparison table."""
    rows = []
    for m in all_metrics:
        rows.append(
            {
                "Model": m["model"],
                "Accuracy": round(m["accuracy"], 4),
                "Precision": round(m["precision_macro"], 4),
                "Recall": round(m["recall_macro"], 4),
                "F1 (macro)": round(m["f1_macro"], 4),
                "AUC-ROC": round(m["auc_roc_ovr"], 4) if m.get("auc_roc_ovr") else None,
                "U2R recall": round(m["per_class"]["U2R"]["recall"], 4),
                "R2L recall": round(m["per_class"]["R2L"]["recall"], 4),
            }
        )
    return pd.DataFrame(rows)


def plot_comparison(df: pd.DataFrame, save: bool = True):
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    metrics_to_plot = ["Accuracy", "Precision", "Recall", "F1 (macro)"]
    x = np.arange(len(df))
    width = 0.2

    fig, ax = plt.subplots(figsize=(10, 5))
    for i, metric in enumerate(metrics_to_plot):
        ax.bar(x + i * width, df[metric], width, label=metric)

    ax.set_xticks(x + width * 1.5, df["Model"])
    ax.set_ylim(0, 1.05)
    ax.set_ylabel("Score")
    ax.set_title("Model comparison on the NSL-KDD test set")
    ax.legend(loc="lower right")
    ax.grid(axis="y", alpha=0.3)
    fig.tight_layout()

    if save:
        fig.savefig(FIGURE_DIR / "model_comparison.png", dpi=150)
    plt.close(fig)
