"""CNN-LSTM hybrid detector.

The feature vector for a connection record is treated as a one dimensional
sequence. Stacked Conv1D blocks pick up local groupings of correlated features,
for example the cluster of dst_host_* statistics that together characterise a
port sweep, and the LSTM layer then reads the resulting feature maps in order to
model longer range dependencies across the vector.

This is the architecture that tends to win on Probe and R2L, where the signal
lives in combinations of features rather than in any single one.
"""

from __future__ import annotations

import numpy as np
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers

from src.config import CNN_LSTM_PARAMS, MODEL_DIR, N_CLASSES, RANDOM_STATE


def reshape_for_sequence(X: np.ndarray) -> np.ndarray:
    """Add the channel axis Conv1D expects: (samples, timesteps, 1)."""
    return X.reshape((X.shape[0], X.shape[1], 1))


def build(n_features: int) -> keras.Model:
    tf.random.set_seed(RANDOM_STATE)
    inputs = keras.Input(shape=(n_features, 1), name="traffic_sequence")

    x = inputs
    for filters in CNN_LSTM_PARAMS["conv_filters"]:
        x = layers.Conv1D(
            filters=filters,
            kernel_size=CNN_LSTM_PARAMS["kernel_size"],
            padding="same",
            activation="relu",
        )(x)
        x = layers.BatchNormalization()(x)
        x = layers.MaxPooling1D(pool_size=2)(x)

    x = layers.LSTM(CNN_LSTM_PARAMS["lstm_units"], return_sequences=False)(x)
    x = layers.Dropout(CNN_LSTM_PARAMS["dropout"])(x)
    x = layers.Dense(64, activation="relu")(x)
    x = layers.Dropout(CNN_LSTM_PARAMS["dropout"])(x)
    outputs = layers.Dense(N_CLASSES, activation="softmax", name="attack_class")(x)

    model = keras.Model(inputs, outputs, name="cnn_lstm_nids")
    model.compile(
        optimizer=keras.optimizers.Adam(CNN_LSTM_PARAMS["learning_rate"]),
        loss="sparse_categorical_crossentropy",
        metrics=["accuracy"],
    )
    return model


def train(
    X_train: np.ndarray,
    y_train: np.ndarray,
    X_val: np.ndarray,
    y_val: np.ndarray,
    verbose: int = 1,
) -> tuple[keras.Model, keras.callbacks.History]:
    X_train_seq = reshape_for_sequence(X_train)
    X_val_seq = reshape_for_sequence(X_val)

    model = build(X_train.shape[1])
    callbacks = [
        keras.callbacks.EarlyStopping(
            monitor="val_loss", patience=6, restore_best_weights=True
        ),
        keras.callbacks.ReduceLROnPlateau(
            monitor="val_loss", factor=0.5, patience=3, min_lr=1e-5
        ),
    ]
    history = model.fit(
        X_train_seq,
        y_train,
        validation_data=(X_val_seq, y_val),
        epochs=CNN_LSTM_PARAMS["epochs"],
        batch_size=CNN_LSTM_PARAMS["batch_size"],
        callbacks=callbacks,
        verbose=verbose,
    )
    return model, history


def save(model: keras.Model, name: str = "cnn_lstm.keras") -> None:
    model.save(MODEL_DIR / name)


def load(name: str = "cnn_lstm.keras") -> keras.Model:
    return keras.models.load_model(MODEL_DIR / name)
