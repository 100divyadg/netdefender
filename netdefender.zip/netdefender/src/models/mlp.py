"""Multilayer Perceptron for intrusion classification.

A plain fully connected network with ReLU activations, batch normalisation and
dropout, ending in a softmax over the five attack classes. It is the simplest
of the two deep models and serves to isolate how much of the deep learning gain
comes from depth alone rather than from the convolutional or recurrent
structure used in the hybrid.
"""

from __future__ import annotations

import numpy as np
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers

from src.config import MLP_PARAMS, MODEL_DIR, N_CLASSES, RANDOM_STATE


def build(n_features: int) -> keras.Model:
    tf.random.set_seed(RANDOM_STATE)
    inputs = keras.Input(shape=(n_features,), name="traffic_features")
    x = inputs
    for units in MLP_PARAMS["hidden_units"]:
        x = layers.Dense(units, activation="relu")(x)
        x = layers.BatchNormalization()(x)
        x = layers.Dropout(MLP_PARAMS["dropout"])(x)
    outputs = layers.Dense(N_CLASSES, activation="softmax", name="attack_class")(x)

    model = keras.Model(inputs, outputs, name="mlp_nids")
    model.compile(
        optimizer=keras.optimizers.Adam(MLP_PARAMS["learning_rate"]),
        loss="sparse_categorical_crossentropy",
        metrics=["accuracy"],
    )
    return model


def train(
    X_train: np.ndarray,
    y_train: np.ndarray,
    X_val: np.ndarray,
    y_val: np.ndarray,
    verbose: int = 1,
) -> tuple[keras.Model, keras.callbacks.History]:
    model = build(X_train.shape[1])
    callbacks = [
        keras.callbacks.EarlyStopping(
            monitor="val_loss", patience=6, restore_best_weights=True
        ),
        keras.callbacks.ReduceLROnPlateau(
            monitor="val_loss", factor=0.5, patience=3, min_lr=1e-5
        ),
    ]
    history = model.fit(
        X_train,
        y_train,
        validation_data=(X_val, y_val),
        epochs=MLP_PARAMS["epochs"],
        batch_size=MLP_PARAMS["batch_size"],
        callbacks=callbacks,
        verbose=verbose,
    )
    return model, history


def save(model: keras.Model, name: str = "mlp.keras") -> None:
    model.save(MODEL_DIR / name)


def load(name: str = "mlp.keras") -> keras.Model:
    return keras.models.load_model(MODEL_DIR / name)
