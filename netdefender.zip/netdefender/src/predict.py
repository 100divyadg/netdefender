"""Inference service.

Loads whichever trained models are on disk and exposes a single predict entry
point that returns a class label with a confidence score. The Flask app talks
only to this module, so swapping the backing model never touches the web layer.
"""

from __future__ import annotations

from typing import Any

import joblib
import numpy as np
import pandas as pd

from src.config import (
    CLASS_NAMES,
    COLUMN_NAMES,
    DROP_COLUMNS,
    MODEL_DIR,
    NORMAL_CLASS,
)


class Detector:
    """Wraps the trained artefacts and applies the saved preprocessing."""

    def __init__(self, model_name: str = "random_forest") -> None:
        self.model_name = model_name
        self.encoder = self._load_joblib("encoder.joblib")
        self.label_encoder = self._load_joblib("label_encoder.joblib")
        self.pca = self._load_joblib("pca.joblib", required=False)
        self.model = self._load_model(model_name)

    # -- loading ----------------------------------------------------------
    @staticmethod
    def _load_joblib(name: str, required: bool = True):
        path = MODEL_DIR / name
        if not path.exists():
            if required:
                raise FileNotFoundError(
                    f"{name} not found. Run `python -m src.train` first."
                )
            return None
        return joblib.load(path)

    def _load_model(self, name: str):
        if name == "random_forest":
            return self._load_joblib("random_forest.joblib")
        if name in {"mlp", "cnn_lstm"}:
            from tensorflow import keras

            path = MODEL_DIR / f"{name}.keras"
            if not path.exists():
                raise FileNotFoundError(f"{path} not found. Train it first.")
            return keras.models.load_model(path)
        raise ValueError(f"unknown model: {name}")

    def available_models(self) -> list[str]:
        found = []
        if (MODEL_DIR / "random_forest.joblib").exists():
            found.append("random_forest")
        for n in ("mlp", "cnn_lstm"):
            if (MODEL_DIR / f"{n}.keras").exists():
                found.append(n)
        return found

    # -- transformation ---------------------------------------------------
    def _to_frame(self, record: dict[str, Any] | pd.DataFrame) -> pd.DataFrame:
        if isinstance(record, pd.DataFrame):
            df = record.copy()
        else:
            df = pd.DataFrame([record])

        feature_cols = [
            c for c in COLUMN_NAMES if c not in DROP_COLUMNS + ["outcome"]
        ]
        for col in feature_cols:
            if col not in df.columns:
                df[col] = 0
        return df[feature_cols]

    def _transform(self, df: pd.DataFrame) -> np.ndarray:
        X = self.encoder.transform(df)
        if self.pca is not None:
            X = self.pca.transform(X)
        return np.asarray(X, dtype=np.float32)

    # -- prediction -------------------------------------------------------
    def predict(self, record: dict[str, Any] | pd.DataFrame) -> dict[str, Any]:
        """Classify one or many connection records."""
        df = self._to_frame(record)
        X = self._transform(df)

        if self.model_name == "cnn_lstm":
            X = X.reshape((X.shape[0], X.shape[1], 1))

        if hasattr(self.model, "predict_proba"):
            proba = self.model.predict_proba(X)
        else:
            proba = self.model.predict(X, verbose=0)

        idx = int(np.argmax(proba[0]))
        label = CLASS_NAMES[idx]

        return {
            "prediction": label,
            "is_attack": label != NORMAL_CLASS,
            "confidence": float(proba[0][idx]),
            "probabilities": {
                CLASS_NAMES[i]: float(p) for i, p in enumerate(proba[0])
            },
            "model": self.model_name,
        }

    def predict_batch(self, df: pd.DataFrame) -> pd.DataFrame:
        """Classify a whole DataFrame of records at once."""
        frame = self._to_frame(df)
        X = self._transform(frame)
        if self.model_name == "cnn_lstm":
            X = X.reshape((X.shape[0], X.shape[1], 1))

        if hasattr(self.model, "predict_proba"):
            proba = self.model.predict_proba(X)
        else:
            proba = self.model.predict(X, verbose=0)

        idx = np.argmax(proba, axis=1)
        out = df.copy()
        out["prediction"] = [CLASS_NAMES[i] for i in idx]
        out["confidence"] = proba[np.arange(len(idx)), idx]
        out["is_attack"] = out["prediction"] != NORMAL_CLASS
        return out
