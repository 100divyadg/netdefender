"""Train and compare all three intrusion detection models.

Usage
-----
    python -m src.train                    # all models, SMOTE on
    python -m src.train --models rf mlp    # subset
    python -m src.train --no-smote --pca   # ablation run
"""

from __future__ import annotations

import argparse
import time

import numpy as np

from src.config import METRIC_DIR, RESULTS_DIR
from src.data import preprocess
from src.models import random_forest
from src.utils import evaluate

# The Keras models are imported inside their runners so that the Random Forest
# baseline can be trained on a machine without TensorFlow installed.

MODEL_CHOICES = ["rf", "mlp", "cnn_lstm"]


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Train NetDefender models")
    p.add_argument("--models", nargs="+", choices=MODEL_CHOICES, default=MODEL_CHOICES)
    p.add_argument("--no-smote", action="store_true", help="disable SMOTE balancing")
    p.add_argument("--pca", action="store_true", help="apply PCA reduction")
    p.add_argument("--quiet", action="store_true")
    return p.parse_args()


def run_random_forest(data: preprocess.Dataset, verbose: int) -> dict:
    print("\n>>> Training Random Forest")
    t0 = time.time()
    model = random_forest.train(data.X_train, data.y_train)
    elapsed = time.time() - t0

    y_pred = model.predict(data.X_test)
    y_proba = model.predict_proba(data.X_test)
    metrics = evaluate.compute_metrics(data.y_test, y_pred, y_proba, "Random Forest")
    metrics["train_seconds"] = round(elapsed, 2)

    random_forest.save(model)
    if data.feature_names:
        importance = random_forest.feature_importance(model, data.feature_names)
        importance.to_csv(METRIC_DIR / "feature_importance.csv", index=False)
        print("\n  Top 10 features")
        print(importance.head(10).to_string(index=False))
    return metrics


def run_mlp(data: preprocess.Dataset, verbose: int) -> dict:
    from src.models import mlp

    print("\n>>> Training MLP")
    t0 = time.time()
    model, _ = mlp.train(data.X_train, data.y_train, data.X_val, data.y_val, verbose)
    elapsed = time.time() - t0

    y_proba = model.predict(data.X_test, verbose=0)
    y_pred = np.argmax(y_proba, axis=1)
    metrics = evaluate.compute_metrics(data.y_test, y_pred, y_proba, "MLP")
    metrics["train_seconds"] = round(elapsed, 2)

    mlp.save(model)
    return metrics


def run_cnn_lstm(data: preprocess.Dataset, verbose: int) -> dict:
    from src.models import cnn_lstm

    print("\n>>> Training CNN-LSTM")
    t0 = time.time()
    model, _ = cnn_lstm.train(
        data.X_train, data.y_train, data.X_val, data.y_val, verbose
    )
    elapsed = time.time() - t0

    X_test_seq = cnn_lstm.reshape_for_sequence(data.X_test)
    y_proba = model.predict(X_test_seq, verbose=0)
    y_pred = np.argmax(y_proba, axis=1)
    metrics = evaluate.compute_metrics(data.y_test, y_pred, y_proba, "CNN-LSTM")
    metrics["train_seconds"] = round(elapsed, 2)

    cnn_lstm.save(model)
    return metrics


def main() -> None:
    args = parse_args()
    verbose = 0 if args.quiet else 1

    print("Preparing NSL-KDD dataset")
    data = preprocess.prepare(use_smote=not args.no_smote, use_pca=args.pca)
    print(f"  {data.summary()}")
    print(f"  class distribution: {np.bincount(data.y_train).tolist()}")

    runners = {"rf": run_random_forest, "mlp": run_mlp, "cnn_lstm": run_cnn_lstm}

    all_metrics = []
    for key in args.models:
        metrics = runners[key](data, verbose)
        evaluate.print_report(metrics)
        evaluate.save_metrics(metrics)
        evaluate.plot_confusion_matrix(metrics)
        all_metrics.append(metrics)

    if len(all_metrics) > 1:
        table = evaluate.comparison_table(all_metrics)
        print(f"\n{'=' * 62}\n  MODEL COMPARISON\n{'=' * 62}")
        print(table.to_string(index=False))
        table.to_csv(RESULTS_DIR / "comparison.csv", index=False)
        evaluate.plot_comparison(table)
        print(f"\nArtefacts written to {RESULTS_DIR}")


if __name__ == "__main__":
    main()
