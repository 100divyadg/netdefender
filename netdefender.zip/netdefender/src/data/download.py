"""Fetch the NSL-KDD dataset into data/raw.

The dataset is distributed publicly by the Canadian Institute for Cybersecurity.
Run this once before training:

    python -m src.data.download
"""

from __future__ import annotations

import sys
import urllib.request

from src.config import RAW_DIR, TEST_FILE, TRAIN_FILE

MIRROR = "https://raw.githubusercontent.com/defcom17/NSL_KDD/master"

FILES = {
    "KDDTrain+.txt": f"{MIRROR}/KDDTrain%2B.txt",
    "KDDTest+.txt": f"{MIRROR}/KDDTest%2B.txt",
}


def download() -> None:
    RAW_DIR.mkdir(parents=True, exist_ok=True)
    for name, url in FILES.items():
        target = RAW_DIR / name
        if target.exists():
            print(f"[skip] {name} already present")
            continue
        print(f"[get ] {name} from {url}")
        try:
            urllib.request.urlretrieve(url, target)
        except Exception as exc:  # noqa: BLE001
            print(f"[fail] could not download {name}: {exc}", file=sys.stderr)
            print(
                "Download it manually from "
                "https://www.unb.ca/cic/datasets/nsl.html "
                f"and place it at {target}",
                file=sys.stderr,
            )
            continue
        print(f"[done] saved to {target}")

    missing = [p for p in (TRAIN_FILE, TEST_FILE) if not p.exists()]
    if missing:
        print("\nStill missing:", ", ".join(p.name for p in missing))
    else:
        print("\nDataset ready.")


if __name__ == "__main__":
    download()
